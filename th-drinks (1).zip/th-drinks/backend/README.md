# Backend — TH DRINKS

1. Copie .env.example para .env e ajuste as variáveis
2. npm install
3. npm run dev

Observação: esta implementação é um esqueleto com armazenamento em memória e rotas de demonstração. Substitua por Postgres e lógica de autenticação antes de produção.
