const { Server } = require('socket.io');

let io;
module.exports.initSockets = (server) => {
  io = new Server(server, { cors: { origin: process.env.FRONTEND_URL || '*' } });

  io.on('connection', (socket) => {
    console.log('socket connected', socket.id);

    socket.on('join_event', ({ eventId, role }) => {
      socket.join(`event:${eventId}`);
      if (role === 'kitchen') socket.join(`kitchen:${eventId}`);
    });

    socket.on('leave_event', ({ eventId }) => {
      socket.leave(`event:${eventId}`);
    });

    socket.on('disconnect', () => {
      // console.log('socket disconnected', socket.id)
    });
  });
};

module.exports.io = () => io;
