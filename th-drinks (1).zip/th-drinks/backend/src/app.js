const express = require('express');
const cors = require('cors');
const events = require('./routes/events');
const drinks = require('./routes/drinks');
const orders = require('./routes/orders');
const qr = require('./routes/qr');

const app = express();
app.use(cors());
app.use(express.json());

app.use('/api/events', events);
app.use('/api/drinks', drinks);
app.use('/api/orders', orders);
app.use('/api/qr', qr);

app.get('/', (req, res) => res.send({ ok: true, name: 'TH DRINKS API' }));

module.exports = app;
