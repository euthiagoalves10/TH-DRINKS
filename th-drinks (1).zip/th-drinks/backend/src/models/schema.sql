-- Postgres minimal schema
CREATE TABLE events (
  id uuid PRIMARY KEY,
  name text,
  theme text,
  venue text,
  date timestamptz,
  created_by uuid,
  created_at timestamptz,
  duration_hours int,
  expires_at timestamptz
);

CREATE TABLE users (
  id uuid PRIMARY KEY,
  name text,
  role text,
  coins int DEFAULT 0,
  created_at timestamptz
);

CREATE TABLE drinks (
  id uuid PRIMARY KEY,
  event_id uuid REFERENCES events(id),
  name text,
  short_desc text,
  sensory_desc text,
  ingredients jsonb,
  image_url text,
  coin_cost int DEFAULT 1,
  created_at timestamptz
);

CREATE TABLE orders (
  id uuid PRIMARY KEY,
  event_id uuid REFERENCES events(id),
  drink_id uuid REFERENCES drinks(id),
  guest_id uuid REFERENCES users(id),
  guest_name text,
  quantity int DEFAULT 1,
  status text,
  created_at timestamptz
);
