const express = require('express');
const router = express.Router();
const { io } = require('../sockets');
const { v4: uuid } = require('uuid');

const orders = [];

router.post('/', (req, res) => {
  const { eventId, drinkId, guestId, guestName, quantity = 1 } = req.body;
  // validate coins in real impl
  const order = { id: uuid(), eventId, drinkId, guestId, guestName, quantity, status: 'pending', created_at: new Date() };
  orders.push(order);

  // emit to kitchen room
  const socketio = io();
  if (socketio) socketio.to(`kitchen:${eventId}`).emit('new_order', order);

  res.json(order);
});

router.get('/:eventId', (req, res) => {
  res.json(orders.filter(o => o.eventId === req.params.eventId));
});

module.exports = router;
