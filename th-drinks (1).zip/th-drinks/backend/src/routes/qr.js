const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const { v4: uuid } = require('uuid');

const QR_STORE = {}; // in-memory

router.post('/generate', (req, res) => {
  const { eventId, amount, expires_in_hours = 6 } = req.body; // ADM endpoint
  const payload = { eventId, amount, nonce: uuid() };
  const token = jwt.sign(payload, process.env.JWT_SECRET || 'dev_secret', { expiresIn: `${expires_in_hours}h` });
  QR_STORE[token] = { eventId, amount, created_at: new Date() };
  res.json({ token, qrUrl: `/api/qr/redeem?token=${encodeURIComponent(token)}` });
});

router.post('/redeem', (req, res) => {
  const { token, guestId } = req.body;
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET || 'dev_secret');
    // add coins to guestId in real impl
    res.json({ ok: true, amount: payload.amount });
  } catch (err) {
    return res.status(400).json({ ok: false, message: 'Token inválido ou expirado' });
  }
});

module.exports = router;
