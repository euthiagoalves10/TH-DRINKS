const express = require('express');
const router = express.Router();
const { v4: uuid } = require('uuid');

// NOTE: In a real project, connect to DB and save events.
router.post('/', async (req, res) => {
  const { name, theme, duration_hours, date, venue } = req.body;
  const id = uuid();
  const created_at = new Date();
  const expires_at = new Date(Date.now() + (duration_hours || 5) * 3600 * 1000);
  // Persist to DB... returning simulated data for skeleton
  res.json({ id, name, theme, created_at, expires_at });
});

router.get('/:id', async (req, res) => {
  // fetch event by id
  res.json({ id: req.params.id, name: 'Demo Event', expires_at: new Date(Date.now() + 3600 * 1000) });
});

module.exports = router;
