const express = require('express');
const router = express.Router();
const { v4: uuid } = require('uuid');

// Temporary in-memory store (MVP)
const drinks = {};

router.post('/:eventId', (req, res) => {
  const id = uuid();
  const { name, short_desc, sensory_desc, ingredients, image_url, coin_cost = 1 } = req.body;
  drinks[id] = { id, eventId: req.params.eventId, name, short_desc, sensory_desc, ingredients, image_url, coin_cost };
  res.json(drinks[id]);
});

router.get('/:eventId', (req, res) => {
  const list = Object.values(drinks).filter(d => d.eventId === req.params.eventId);
  res.json(list);
});

module.exports = router;
