const jwt = require('jsonwebtoken');

const sign = (payload, expiresIn = '6h') => {
  return jwt.sign(payload, process.env.JWT_SECRET || 'dev_secret', { expiresIn });
}

const verify = (token) => {
  return jwt.verify(token, process.env.JWT_SECRET || 'dev_secret');
}

module.exports = { sign, verify };
