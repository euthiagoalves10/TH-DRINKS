// placeholder db helper - in real impl use pg.Pool
module.exports = {
  query: async () => { throw new Error('DB not configured'); }
}
