# TH DRINKS

## Como rodar localmente

### Backend
cd backend
cp .env.example .env
# ajustar variáveis se precisar
npm install
npm run dev

### Frontend
cd frontend
npm install
npm run dev

Acesse: http://localhost:5173 (frontend) — API padrão: http://localhost:4000/api
