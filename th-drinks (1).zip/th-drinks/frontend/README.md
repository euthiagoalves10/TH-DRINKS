# Frontend — TH DRINKS

1. npm install
2. npm run dev

Ajuste a variável VITE_API_URL no .env local (se necessário) para apontar para o backend.
