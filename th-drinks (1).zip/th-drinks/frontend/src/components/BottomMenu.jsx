import React from 'react'

export default function BottomMenu(){
  return (
    <nav className="fixed bottom-4 left-0 right-0 flex justify-center">
      <div className="bg-black/60 px-6 py-3 rounded-full shadow-lg flex gap-6">
        <button>MENU</button>
        <button>PEDIDOS</button>
        <button>QR CODE</button>
        <button>PERFIL</button>
      </div>
    </nav>
  )
}
