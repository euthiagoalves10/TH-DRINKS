import React, { useState } from 'react'
import api from '../lib/api'

export default function OrderModal({ drink, onClose }){
  const [qty, setQty] = useState(1)

  const order = async () => {
    try{
      const payload = { eventId: 'demo-event', drinkId: drink.id, guestId: 'guest-1', guestName: 'Fulano', quantity: qty }
      await api.post('/orders', payload)
      onClose()
    }catch(err){
      alert('Erro ao enviar pedido')
    }
  }

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center p-4">
      <div className="bg-gray-900 rounded-xl w-full max-w-xl p-6">
        <img src={drink.image_url || 'https://via.placeholder.com/600x400'} alt="" className="w-full h-64 object-cover rounded" />
        <h2 className="text-2xl font-bold mt-4">{drink.name}</h2>
        <p className="mt-2 text-gray-300">{drink.sensory_desc}</p>
        <div className="mt-4 flex items-center gap-3">
          <button onClick={()=>setQty(Math.max(1, qty-1))} className="px-3 py-1 bg-white/5 rounded">-</button>
          <div className="px-4">{qty}</div>
          <button onClick={()=>setQty(qty+1)} className="px-3 py-1 bg-white/5 rounded">+</button>
        </div>
        <div className="mt-4 flex gap-3">
          <button onClick={order} className="neon-btn px-6 py-2">Pedir</button>
          <button onClick={onClose} className="px-6 py-2 bg-white/5 rounded">Fechar</button>
        </div>
      </div>
    </div>
  )
}
