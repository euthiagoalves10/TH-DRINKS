import React from 'react'

export default function DrinkCard({ drink, onOpen }){
  return (
    <div className="bg-white/5 rounded-xl overflow-hidden shadow-md">
      <img src={drink.image_url || 'https://via.placeholder.com/400x300'} alt={drink.name} className="w-full h-48 object-cover" />
      <div className="p-3">
        <h3 className="font-semibold text-lg">{drink.name}</h3>
        <p className="text-sm text-gray-300">{drink.short_desc}</p>
        <div className="mt-3">
          <button onClick={()=>onOpen(drink)} className="px-4 py-2 rounded-lg neon-btn">Ver +</button>
        </div>
      </div>
    </div>
  )
}
