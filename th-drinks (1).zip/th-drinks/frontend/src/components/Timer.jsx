import React, { useEffect, useState } from 'react'

export default function Timer({ expiresAt }){
  const [now, setNow] = useState(Date.now())
  useEffect(()=>{
    const t = setInterval(()=> setNow(Date.now()), 1000)
    return ()=>clearInterval(t)
  },[])
  const diff = Math.max(0, Math.floor((expiresAt - now)/1000))
  const hh = String(Math.floor(diff/3600)).padStart(2,'0')
  const mm = String(Math.floor((diff%3600)/60)).padStart(2,'0')
  const ss = String(diff%60).padStart(2,'0')
  return <div className="text-right">{hh}:{mm}:{ss}</div>
}
