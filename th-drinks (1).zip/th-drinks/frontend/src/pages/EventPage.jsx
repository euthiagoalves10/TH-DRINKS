import React, { useEffect, useState } from 'react'
import DrinkCard from '../components/DrinkCard'
import OrderModal from '../components/OrderModal'
import Timer from '../components/Timer'
import api from '../lib/api'

export default function EventPage(){
  const [drinks, setDrinks] = useState([])
  const [selected, setSelected] = useState(null)
  const eventId = 'demo-event'

  useEffect(()=>{
    async function load(){
      try{
        const res = await api.get(`/drinks/${eventId}`)
        setDrinks(res.data || [])
      }catch(err){ console.error(err) }
    }
    load()
  },[])

  return (
    <div className="p-4 max-w-5xl mx-auto">
      <header className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold">SEJA BEM VINDO AO BAR DO JOEL</h1>
          <p>12/12/2025 — Espaço X</p>
        </div>
        <Timer expiresAt={Date.now()+1000*60*60*4} />
      </header>

      <section className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {drinks.map(d => (
          <DrinkCard key={d.id} drink={d} onOpen={setSelected} />
        ))}
      </section>

      {selected && <OrderModal drink={selected} onClose={()=>setSelected(null)} />}

      <nav className="fixed bottom-4 left-0 right-0 flex justify-center">
        <div className="bg-black/60 px-6 py-3 rounded-full shadow-lg flex gap-6">
          <button>MENU</button>
          <button>PEDIDOS</button>
          <button>QR CODE</button>
          <button>PERFIL</button>
        </div>
      </nav>
    </div>
  )
}
